<?php
// Print the date and time
echo date('l jS \of F Y h:i:s A');
?>
